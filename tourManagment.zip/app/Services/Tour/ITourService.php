<?php

namespace App\Services\Tour;

use phpDocumentor\Reflection\Types\Integer;

interface ITourService
{
    public function calculatePrice();
}
;
