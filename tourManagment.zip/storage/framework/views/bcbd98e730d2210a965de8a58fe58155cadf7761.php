<body>
Information user  and tour send to admin
user email: <?php echo e($user->email); ?>

user phone : <?php echo e($user->phone); ?>

tour title : <?php echo e($tour->title); ?>

tour description : <?php echo e($tour->description); ?>

tour_price : <?php echo e($tour_price); ?>

</body>
<?php /**PATH /home/mohammadreza/project/part/part/resources/views/layouts/UserInformationMail.blade.php ENDPATH**/ ?>