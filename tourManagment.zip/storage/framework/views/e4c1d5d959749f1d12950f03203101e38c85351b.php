<body>
Registered Confirm
<?php echo e($user->name); ?>

<?php echo e($user->phone); ?>

you are regiter in tour.
</body>
<?php /**PATH /home/mohammadreza/project/part/part/resources/views/layouts/RegisteredConfirmMail.blade.php ENDPATH**/ ?>