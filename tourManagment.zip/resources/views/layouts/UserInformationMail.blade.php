<body>
Information user  and tour send to admin
user email: {{$user->email}}
user phone : {{$user->phone}}
tour title : {{$tour->title}}
tour description : {{$tour->description}}
tour_price : {{$tour_price}}
</body>
