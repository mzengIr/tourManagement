<body>
Registered Confirm
{{$user->name}}
{{$user->phone}}
you are regiter in tour.
</body>
